import { motion } from "framer-motion";

const STATS = [
  {
    number: "500+",
    label: "Manufacturing SMEs",
  },
  {
    number: "2,500+",
    label: "Engineers & Builders",
  },
  {
    number: "120+",
    label: "Universities & Polytechnics",
  },
  {
    number: "37",
    label: "States Connected",
  },
  {
    number: "1,000+",
    label: "Youth Builders",
  },
  {
    number: "150+",
    label: "Vehicle Components",
  },
];

export default function ImpactStats() {
  return (
    <section className="forge-section forge-impact">
      <div className="wrap">

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <div className="section-kicker">
            LIVE IMPACT
          </div>

          <h2 className="section-title">
            Building Africa's Manufacturing Operating System
          </h2>

          <p className="section-copy">
            Every builder, every SME and every institution strengthens
            Africa's distributed manufacturing network.
          </p>
        </motion.div>

        <div className="cards three">

          {STATS.map((item) => (
            <motion.div
              key={item.label}
              className="card stat-card"
              whileHover={{
                y: -8,
                scale: 1.03,
              }}
            >
              <h1>{item.number}</h1>

              <span>{item.label}</span>

            </motion.div>
          ))}

        </div>

      </div>
    </section>
  );
}