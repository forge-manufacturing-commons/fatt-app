import { motion } from "framer-motion";

const STEPS = [
  {
    number: "01",
    title: "Design",
    text: "Engineers, designers and universities create digital vehicle systems that are divided into manufacturable components.",
  },
  {
    number: "02",
    title: "Forge",
    text: "SMEs across Nigeria manufacture assigned components simultaneously using the Forge manufacturing network.",
  },
  {
    number: "03",
    title: "Assemble",
    text: "Completed parts converge for quality assurance, integration, testing and deployment as a finished vehicle.",
  },
];

export default function HowItWorks() {
  return (
    <section className="forge-section">
      <div className="wrap">

        <div className="section-kicker">
          HOW FORGE WORKS
        </div>

        <h2 className="section-title">
          One Truck. Thousands of Builders.
        </h2>

        <p className="section-copy">
          Forge coordinates distributed manufacturing so hundreds of
          independent workshops can build one vehicle together.
        </p>

        <div className="cards three">

          {STEPS.map((step) => (
            <motion.div
              key={step.number}
              className="card"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              whileHover={{
                y: -10,
                scale: 1.02,
              }}
            >
              <div
                style={{
                  fontSize: "3rem",
                  fontWeight: 800,
                  color: "var(--forge-gold)",
                  marginBottom: "1rem",
                }}
              >
                {step.number}
              </div>

              <h3>{step.title}</h3>

              <p>{step.text}</p>
            </motion.div>
          ))}

        </div>

      </div>
    </section>
  );
}