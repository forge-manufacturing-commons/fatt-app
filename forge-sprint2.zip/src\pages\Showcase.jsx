import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

import HeroSection from "../components/hero/HeroSection";

import { fetchJobs } from "../lib/supabase";
import { GALLERY } from "../lib/assets";
import NigeriaMap from "../components/manufacturing/NigeriaMap";
import WhyForge from "../components/showcase/WhyForge";
import ImpactStats from "../components/showcase/ImpactStats";
import HowItWorks from "../components/showcase/HowItWorks";

function badge(stage) {
  switch (stage) {
    case "done":
      return <span className="badge badge-done">Completed</span>;

    case "qa":
      return <span className="badge badge-qa">Quality Assurance</span>;

    case "fabricating":
      return <span className="badge badge-live">Fabricating</span>;

    default:
      return <span className="badge badge-queue">Queued</span>;
  }
}

export default function Showcase() {

  const navigate = useNavigate();

  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetchJobs().then(setJobs);
  }, []);

  const builders = jobs.reduce(
    (total, item) => total + item.head_count,
    0
  );

  const completed = jobs.filter(
    item => item.stage === "done"
  ).length;

  return (

    <>

      {/* =======================================================
          HERO
      ======================================================== */}

      <HeroSection />

      {/* =======================================================
          LIVE IMPACT BAR
      ======================================================== */}

      <section className="forge-impact">

        <div className="impact-grid">

          <motion.div
            className="impact-card"
            whileHover={{ y: -8 }}
          >

            <div className="impact-number">

              {jobs.length}

            </div>

            <div className="impact-label">

              Manufacturing Components

            </div>

          </motion.div>

          <motion.div
            className="impact-card"
            whileHover={{ y: -8 }}
          >

            <div className="impact-number">

              {builders}

            </div>

            <div className="impact-label">

              Youth Builders

            </div>

          </motion.div>

          <motion.div
            className="impact-card"
            whileHover={{ y: -8 }}
          >

            <div className="impact-number">

              {completed}

              <span className="impact-small">

                / {jobs.length}

              </span>

            </div>

            <div className="impact-label">

              Components Completed

            </div>

          </motion.div>

          <motion.div
            className="impact-card"
            whileHover={{ y: -8 }}
          >

            <div className="impact-number">

              7

            </div>

            <div className="impact-label">

              Ecosystem Stakeholders

            </div>

          </motion.div>

        </div>

      </section>


      <NigeriaMap />
      
      <WhyForge />

      <ImpactStats />

      <HowItWorks />

      {/* =======================================================
          WHY FORGE
          (continues in Part 2)
      ======================================================== */}
            <section className="forge-section why-forge">

        <div className="wrap">

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: .7 }}
            viewport={{ once: true }}
          >

            <div className="section-kicker">

              WHY FORGE?

            </div>

            <h2 className="section-title">

              Africa can build
              <br />
              the vehiclesS
              <span className="cyan"> it imports.</span>

            </h2>

            <p className="section-copy">

              Forge-A-Truck-Thon is building Africa's distributed
              manufacturing platform.

              Instead of one factory making an entire vehicle,
              hundreds of SMEs fabricate components,
              universities and polytechnics contribute research,
              youths gain industrial skills,
              engineers validate designs,
              diaspora experts mentor remotely,
              government enables scale,
              while industry commercializes innovation.

            </p>

          </motion.div>

          <div className="forge-principles">

            <motion.div
              whileHover={{ y: -8 }}
              className="principle-card"
            >

              <div className="principle-number">

                01

              </div>

              <h3>

                Distributed Manufacturing

              </h3>

              <p>

                Hundreds of Nigerian SMEs fabricate
                standardized vehicle components simultaneously.

              </p>

            </motion.div>

            <motion.div
              whileHover={{ y: -8 }}
              className="principle-card"
            >

              <div className="principle-number">

                02

              </div>

              <h3>

                Open Engineering

              </h3>

              <p>

                Engineers,
                researchers,
                universities and polytechnics
                collaborate on one shared digital platform.

              </p>

            </motion.div>

            <motion.div
              whileHover={{ y: -8 }}
              className="principle-card"
            >

              <div className="principle-number">

                03

              </div>

              <h3>

                Industrial Skills

              </h3>

              <p>

                Every completed vehicle
                develops new African manufacturing talent.

              </p>

            </motion.div>

          </div>

        </div>

      </section>

      {/* ======================================================
          ECOSYSTEM
      ====================================================== */}

      <section className="forge-section ecosystem">

        <div className="wrap">

          <div className="section-kicker">

            THE ECOSYSTEM

          </div>

          <h2 className="section-title">

            Built by
            <span className="pink"> collaboration.</span>

          </h2>

          <p className="section-copy">

            Forge connects the entire manufacturing ecosystem
            into one digital workflow.

          </p>

          <div className="ecosystem-grid">

            {[
              "SMEs",
              "Universities & Polytechnics",
              "Youths",
              "Engineers",
              "Diaspora",
              "Government",
              "Industry"
            ].map((item) => (

              <motion.div

                key={item}

                whileHover={{
                  y: -10,
                  scale: 1.04
                }}

                className="ecosystem-node"

              >

                <div className="node-circle">

                  ⚒

                </div>

                <h3>

                  {item}

                </h3>

              </motion.div>

            ))}

          </div>

        </div>

      </section>

      {/* ======================================================
          MANUFACTURING PIPELINE
      ====================================================== */}

      <section className="forge-section pipeline">

        <div className="wrap">

          <div className="section-kicker">

            THE PROCESS

          </div>

          <h2 className="section-title">

            From idea
            <span className="cyan">
              {" "}
              to commercialization.
            </span>

          </h2>

          <div className="pipeline">

            {[
              "Concept",
              "Design",
              "Engineering",
              "Prototype",
              "Fabrication",
              "Quality",
              "Assembly",
              "Deployment"
            ].map((step, index) => (

              <motion.div

                key={step}

                className="pipeline-step"

                initial={{
                  opacity: 0,
                  y: 20
                }}

                whileInView={{
                  opacity: 1,
                  y: 0
                }}

                transition={{
                  delay: index * .08
                }}

                viewport={{
                  once: true
                }}

              >

                <div className="step-number">

                  {String(index + 1).padStart(2, "0")}

                </div>

                <div className="step-title">

                  {step}

                </div>

              </motion.div>

            ))}

          </div>

        </div>

      </section>

      {/* ======================================================
          LIVE BUILD BOARD
          (Continues in Part 3)
      ====================================================== */}
            <section className="forge-section build-board-preview">

        <div className="wrap">

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: .7 }}
            viewport={{ once: true }}
          >

            <div className="section-kicker">

              LIVE BUILD BOARD

            </div>

            <h2 className="section-title">

              Every component has
              <span className="pink"> a builder.</span>

            </h2>

            <p className="section-copy">

              Thousands of components.
              Hundreds of workshops.
              One shared manufacturing platform.

              Every contribution is tracked,
              every milestone recorded,
              every completed component moves Africa
              one step closer to locally manufactured vehicles.

            </p>

          </motion.div>

          <div className="forge-board-grid">

            {jobs.map(job => (

              <motion.div

                key={job.id}

                className="forge-job-card"

                whileHover={{
                  y: -10,
                  scale: 1.02
                }}

              >

                <div className="job-header">

                  <div className="job-title">

                    {job.name}

                  </div>

                  {badge(job.stage)}

                </div>

                <div className="job-detail">

                  {job.detail}

                </div>

                <div className="job-owner">

                  {job.owner_org}

                </div>

                <div className="job-footer">

                  <span>

                    👥 {job.head_count} Builders

                  </span>

                  {job.safety_critical &&

                    <span className="safety-tag">

                      Safety Critical

                    </span>

                  }

                </div>

              </motion.div>

            ))}

          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "50px"
            }}
          >

            <button

              className="forge-button"

              onClick={() => nav("/board")}
            >

              Explore Full Build Board →

            </button>

          </div>

        </div>

      </section>

      {/* =====================================================
          FEATURED VEHICLE
      ===================================================== */}

      {

        GALLERY.length > 0 && (

          <section className="forge-section vehicle-gallery">

            <div className="wrap">

              <div className="section-kicker">

                THE FIRST VEHICLE

              </div>

              <h2 className="section-title">

                Meet
                <span className="cyan">

                  {" "}NAWEDOAM

                </span>

              </h2>

              <p className="section-copy">

                A modular dual-energy food truck designed
                to prove that Africa can manufacture,
                innovate and commercialize its own mobility solutions.

              </p>

            </div>

            <div className="gallery-grid">

              {

                GALLERY.map((image, index) => (

                  <motion.div

                    key={image}

                    className={
                      index === 0
                        ? "gallery-large"
                        : "gallery-small"
                    }

                    whileHover={{
                      scale: 1.03
                    }}

                  >

                    <img

                      src={image}

                      alt={`NAWEDOAM ${index + 1}`}

                      loading="lazy"

                    />

                  </motion.div>

                ))

              }

            </div>

          </section>

        )

      }

      {/* =====================================================
          IMPACT NUMBERS
      ===================================================== */}

      <section className="forge-section impact">

        <div className="wrap">

          <div className="section-kicker">

            WHY THIS MATTERS

          </div>

          <h2 className="section-title">

            Building vehicles.

            <br />

            Building
            <span className="pink">

              {" "}an economy.

            </span>

          </h2>

          <div className="impact-grid">

            <motion.div
              className="impact-card"
              whileHover={{ y: -8 }}
            >

              <h3>

                SMEs

              </h3>

              <div className="impact-number">

                1000+

              </div>

              <p>

                Manufacturing businesses
                connected through Forge.

              </p>

            </motion.div>

            <motion.div
              className="impact-card"
              whileHover={{ y: -8 }}
            >

              <h3>

                Youths

              </h3>

              <div className="impact-number">

                Millions

              </div>

              <p>

                Future industrial workforce
                empowered through practical manufacturing.

              </p>

            </motion.div>

            <motion.div
              className="impact-card"
              whileHover={{ y: -8 }}
            >

              <h3>

                Components

              </h3>

              <div className="impact-number">

                Unlimited

              </div>

              <p>

                Designed once.

                Manufactured everywhere.

              </p>

            </motion.div>

          </div>

        </div>

      </section>

      {/* =====================================================
          CALL TO ACTION
          (Continues in Part 4)
      ===================================================== */}
            <section className="forge-section forge-community">

        <div className="wrap">

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: .8 }}
          >

            <div className="section-kicker">

              JOIN THE MOVEMENT

            </div>

            <h2 className="section-title">

              Africa's next vehicle

              <br />

              starts with

              <span className="cyan">

                {" "}you.

              </span>

            </h2>

            <p className="section-copy">

              Whether you're a small manufacturer,

              an engineer,

              a university,

              a polytechnic,

              a youth,

              a student,

              a diaspora professional,

              an investor,

              or a government institution—

              Forge gives everyone a place to contribute.

            </p>

          </motion.div>

          <div className="role-grid">

            {[
              "SMEs",
              "Universities",
              "Polytechnics",
              "Youths",
              "Students",
              "Engineers",
              "Diaspora",
              "Government",
              "Industry",
              "Investors"
            ].map(role => (

              <motion.div

                key={role}

                whileHover={{
                  y: -10,
                  scale: 1.03
                }}

                className="role-card"

              >

                <div className="role-icon">

                  ⚒

                </div>

                <h3>

                  {role}

                </h3>

              </motion.div>

            ))}

          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              gap: "24px",
              flexWrap: "wrap",
              marginTop: "70px"
            }}
          >

            <button

              className="forge-button"

              onClick={() => nav("/join")}

            >

              Join Forge →

            </button>

            <button

              className="forge-button secondary"

              onClick={() => nav("/board")}

            >

              Explore Build Board

            </button>

          </div>

        </div>

      </section>

      <section className="forge-final">

        <motion.div

          initial={{
            opacity: 0,
            y: 40
          }}

          whileInView={{
            opacity: 1,
            y: 0
          }}

          viewport={{
            once: true
          }}

          transition={{
            duration: .8
          }}

        >

          <div className="forge-final-pattern"></div>

          <h2>

            One Platform.

            <br />

            Thousands of Builders.

          </h2>

          <p>

            Africa's Distributed Manufacturing Platform—

            where SMEs,

            universities,

            polytechnics,

            youths,

            engineers,

            diaspora,

            investors,

            industry,

            and government

            collaborate to design,

            build,

            and commercialize vehicles.

          </p>

          <button

            className="forge-button"

            onClick={() => nav("/join")}

          >

            Start Forging →

          </button>

        </motion.div>

      </section>

    </>

  )

}