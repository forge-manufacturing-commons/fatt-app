export const NETWORK = [

  {
    id: "lagos",
    name: "Lagos",
    x: 22,
    y: 73,
    builders: 842,
    smes: 143,
    universities: 12,
    type: "mega",
  },

  {
    id: "aba",
    name: "Aba",
    x: 69,
    y: 82,
    builders: 311,
    smes: 42,
    universities: 2,
    type: "industrial",
  },

  {
    id: "nnewi",
    name: "Nnewi",
    x: 66,
    y: 74,
    builders: 228,
    smes: 35,
    universities: 1,
    type: "automotive",
  },

  {
    id: "effurun",
    name: "Effurun / Warri",
    x: 52,
    y: 77,
    builders: 486,
    smes: 64,
    engineers: 118,
    youth: 1250,
    type: "fabrication",
    description: "Fabrication • Marine Engineering • Energy Technology",
  },

];