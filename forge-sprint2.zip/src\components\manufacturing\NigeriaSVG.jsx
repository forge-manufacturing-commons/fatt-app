export default function NigeriaSVG() {
  return (
    <svg
      className="forge-nigeria-svg"
      viewBox="0 0 1000 900"
      preserveAspectRatio="xMidYMid meet"
    >
      {/* Glow Filter */}
      <defs>
        <filter id="forgeGlow">
          <feGaussianBlur stdDeviation="8" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <linearGradient id="forgeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0f1412" />
          <stop offset="100%" stopColor="#1a211d" />
        </linearGradient>
      </defs>

      {/* Nigeria Silhouette */}

      <path
        filter="url(#forgeGlow)"
        fill="url(#forgeGradient)"
        stroke="#D4AF37"
        strokeWidth="4"
        d="
        M270 120
        L390 80
        L560 95
        L710 180
        L760 300
        L735 470
        L775 610
        L690 770
        L510 835
        L360 780
        L230 650
        L180 500
        L195 350
        L230 220
        Z
        "
      />

    </svg>
  );
}