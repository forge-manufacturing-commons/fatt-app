import { useState } from "react";
import { motion } from "framer-motion";

import "./NigeriaMap.css";

import { NETWORK } from "./nigeriaData";
import NigeriaSVG from "./NigeriaSVG";
import NetworkNode from "./NetworkNode";
import NetworkLines from "./NetworkLines";
import NetworkTooltip from "./NetworkTooltip";

export default function NigeriaMap() {
  const [activeCity, setActiveCity] = useState(null);

  return (
    <section className="forge-map-section">

      <div className="wrap">

        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <div className="section-kicker">
            THE FORGE CONSTELLATION
          </div>

          <h2 className="section-title">
            Nigeria's Manufacturing Network
          </h2>

          <p className="section-copy">
            Every glowing node represents a manufacturing community inside
            the Forge distributed manufacturing ecosystem.
          </p>
        </motion.div>

        <div className="forge-map-container">

          <NigeriaSVG />

          <NetworkLines cities={NETWORK} />

          {NETWORK.map((city) => (
            <NetworkNode
              key={city.id}
              city={city}
              active={activeCity}
              onEnter={setActiveCity}
              onLeave={() => setActiveCity(null)}
            />
          ))}

          <NetworkTooltip city={activeCity} />

        </div>

      </div>

    </section>
  );
}