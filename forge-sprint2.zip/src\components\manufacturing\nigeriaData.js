export const NETWORK = [
  {
    id: "lagos",
    name: "Lagos",
    x: 17,
    y: 72,
    builders: 842,
    smes: 143,
    universities: 9,
    specialty: "Vehicle Integration",
    level: "mega"
  },

  {
    id: "abuja",
    name: "Abuja",
    x: 46,
    y: 48,
    builders: 281,
    smes: 62,
    universities: 5,
    specialty: "National Coordination",
    level: "capital"
  },

  {
    id: "kaduna",
    name: "Kaduna",
    x: 42,
    y: 33,
    builders: 194,
    smes: 31,
    universities: 4,
    specialty: "Steel Fabrication",
    level: "industrial"
  },

  {
    id: "kano",
    name: "Kano",
    x: 57,
    y: 20,
    builders: 366,
    smes: 88,
    universities: 6,
    specialty: "Metal Processing",
    level: "industrial"
  },

  {
    id: "ilorin",
    name: "Ilorin",
    x: 33,
    y: 56,
    builders: 165,
    smes: 27,
    universities: 3,
    specialty: "Engineering Education",
    level: "technical"
  },

  {
    id: "benin",
    name: "Benin City",
    x: 43,
    y: 72,
    builders: 208,
    smes: 46,
    universities: 3,
    specialty: "Component Fabrication",
    level: "fabrication"
  },

  {
    id: "effurun",
    name: "Effurun / Warri",
    x: 48,
    y: 79,
    builders: 327,
    smes: 64,
    universities: 2,
    specialty: "Forge Alpha Fabrication Hub",
    level: "forge"
  },

  {
    id: "ph",
    name: "Port Harcourt",
    x: 63,
    y: 83,
    builders: 296,
    smes: 55,
    universities: 3,
    specialty: "Energy Systems",
    level: "energy"
  },

  {
    id: "aba",
    name: "Aba",
    x: 66,
    y: 76,
    builders: 311,
    smes: 42,
    universities: 2,
    specialty: "Precision Manufacturing",
    level: "industrial"
  },

  {
    id: "nnewi",
    name: "Nnewi",
    x: 60,
    y: 70,
    builders: 228,
    smes: 35,
    universities: 2,
    specialty: "Automotive Manufacturing",
    level: "automotive"
  }
];