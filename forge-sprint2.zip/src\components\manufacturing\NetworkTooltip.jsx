import { motion, AnimatePresence } from "framer-motion";

export default function NetworkTooltip({ city }) {
  return (
    <AnimatePresence>
      {city && (
        <motion.div
          className="forge-tooltip"
          initial={{ opacity: 0, y: 12, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.95 }}
          transition={{ duration: 0.25 }}
        >
          <h3>{city.name}</h3>

          <div className="tooltip-grid">
            <div>
              <span>Builders</span>
              <strong>{city.builders}</strong>
            </div>

            <div>
              <span>SMEs</span>
              <strong>{city.smes}</strong>
            </div>

            <div>
              <span>Universities</span>
              <strong>{city.universities}</strong>
            </div>
          </div>

          <div className="tooltip-specialty">
            <span>Specialization</span>

            <strong>{city.specialty}</strong>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}