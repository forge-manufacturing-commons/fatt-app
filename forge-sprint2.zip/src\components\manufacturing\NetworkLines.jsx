import { motion } from "framer-motion";

const CONNECTIONS = [
  ["lagos", "ilorin"],
  ["ilorin", "abuja"],
  ["abuja", "kaduna"],
  ["kaduna", "kano"],
  ["lagos", "benin"],
  ["benin", "effurun"],
  ["effurun", "ph"],
  ["ph", "aba"],
  ["aba", "nnewi"],
];

export default function NetworkLines({ cities }) {
  const getCity = (id) => cities.find((city) => city.id === id);

  return (
    <svg
      className="forge-network-lines"
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
    >
      {CONNECTIONS.map(([fromId, toId]) => {
        const from = getCity(fromId);
        const to = getCity(toId);

        if (!from || !to) return null;

        return (
          <motion.line
            key={`${fromId}-${toId}`}
            x1={from.x}
            y1={from.y}
            x2={to.x}
            y2={to.y}
            stroke="#D4AF37"
            strokeWidth="0.35"
            strokeLinecap="round"
            strokeDasharray="2 2"
            initial={{
              pathLength: 0,
              opacity: 0,
            }}
            animate={{
              pathLength: 1,
              opacity: 0.7,
            }}
            transition={{
              duration: 1.4,
            }}
          />
        );
      })}
    </svg>
  );
}