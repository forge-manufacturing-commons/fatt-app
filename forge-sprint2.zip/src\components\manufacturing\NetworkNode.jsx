import { motion } from "framer-motion";

export default function NetworkNode({
  city,
  active,
  onEnter,
  onLeave,
}) {
  return (
    <motion.div
      className={`forge-node ${city.level}`}
      style={{
        left: `${city.x}%`,
        top: `${city.y}%`,
      }}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{
        duration: 0.4,
        delay: 0.08,
      }}
      whileHover={{
        scale: 1.25,
      }}
      onMouseEnter={() => onEnter(city)}
      onMouseLeave={onLeave}
    >
      <span className="forge-node-pulse"></span>

      <span
        className={`forge-node-dot ${
          active?.id === city.id ? "active" : ""
        }`}
      ></span>

      <span className="forge-node-label">
        {city.name}
      </span>
    </motion.div>
  );
}