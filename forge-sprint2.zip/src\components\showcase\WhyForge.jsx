import { motion } from "framer-motion";

const FEATURES = [
  {
    title: "Distributed Manufacturing",
    body:
      "Instead of one giant factory, Forge coordinates hundreds of Nigerian SMEs to manufacture vehicle components simultaneously.",
  },
  {
    title: "University Innovation",
    body:
      "Polytechnics and universities become real manufacturing laboratories where students solve industrial problems instead of theoretical ones.",
  },
  {
    title: "Digital Manufacturing OS",
    body:
      "Forge Alpha coordinates builders, suppliers, fabricators, inspectors and engineers inside one intelligent operating system.",
  },
];

export default function WhyForge() {
  return (
    <section className="forge-section">
      <div className="wrap">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <div className="section-kicker">WHY FORGE</div>

          <h2 className="section-title">
            Manufacturing belongs to everyone.
          </h2>

          <p className="section-copy">
            Forge transforms Nigeria into one coordinated manufacturing
            ecosystem where artisans, SMEs, universities, engineers,
            fabricators and the diaspora build vehicles together.
          </p>
        </motion.div>

        <div className="cards three">
          {FEATURES.map((item) => (
            <motion.div
              key={item.title}
              className="card"
              whileHover={{ y: -10, scale: 1.02 }}
            >
              <h3>{item.title}</h3>

              <p>{item.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}